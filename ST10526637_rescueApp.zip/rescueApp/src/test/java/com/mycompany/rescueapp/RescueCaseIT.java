/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.rescueapp;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Francina
 */
public class RescueCaseIT {
    
    public RescueCaseIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of requireText method, of class RescueCase.
     */
    @Test
    public void testRequireText() {
        System.out.println("requireText");
        String value = "";
        String field = "";
        RescueCase.requireText(value, field);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of requirePositive method, of class RescueCase.
     */
    @Test
    public void testRequirePositive() {
        System.out.println("requirePositive");
        double value = 0.0;
        String field = "";
        RescueCase.requirePositive(value, field);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRescueType method, of class RescueCase.
     */
    @Test
    public void testGetRescueType() {
        System.out.println("getRescueType");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getRescueType();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculateAdditionalCost method, of class RescueCase.
     */
    @Test
    public void testCalculateAdditionalCost() {
        System.out.println("calculateAdditionalCost");
        RescueCase instance = null;
        double expResult = 0.0;
        double result = instance.calculateAdditionalCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of determinePriority method, of class RescueCase.
     */
    @Test
    public void testDeterminePriority() {
        System.out.println("determinePriority");
        RescueCase instance = null;
        RescuePriority expResult = null;
        RescuePriority result = instance.determinePriority();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSpecificDetails method, of class RescueCase.
     */
    @Test
    public void testGetSpecificDetails() {
        System.out.println("getSpecificDetails");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getSpecificDetails();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculateTotalCost method, of class RescueCase.
     */
    @Test
    public void testCalculateTotalCost() {
        System.out.println("calculateTotalCost");
        RescueCase instance = null;
        double expResult = 0.0;
        double result = instance.calculateTotalCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of startRescue method, of class RescueCase.
     */
    @Test
    public void testStartRescue() {
        System.out.println("startRescue");
        RescueCase instance = null;
        instance.startRescue();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of completeRescue method, of class RescueCase.
     */
    @Test
    public void testCompleteRescue() {
        System.out.println("completeRescue");
        RescueCase instance = null;
        instance.completeRescue();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateSummary method, of class RescueCase.
     */
    @Test
    public void testGenerateSummary() {
        System.out.println("generateSummary");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.generateSummary();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of formatMoney method, of class RescueCase.
     */
    @Test
    public void testFormatMoney() {
        System.out.println("formatMoney");
        double amount = 0.0;
        String expResult = "";
        String result = RescueCase.formatMoney(amount);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCaseId method, of class RescueCase.
     */
    @Test
    public void testGetCaseId() {
        System.out.println("getCaseId");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getCaseId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAnimalName method, of class RescueCase.
     */
    @Test
    public void testGetAnimalName() {
        System.out.println("getAnimalName");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getAnimalName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSpecies method, of class RescueCase.
     */
    @Test
    public void testGetSpecies() {
        System.out.println("getSpecies");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getSpecies();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLocation method, of class RescueCase.
     */
    @Test
    public void testGetLocation() {
        System.out.println("getLocation");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getLocation();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRanger method, of class RescueCase.
     */
    @Test
    public void testGetRanger() {
        System.out.println("getRanger");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getRanger();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRescueDays method, of class RescueCase.
     */
    @Test
    public void testGetRescueDays() {
        System.out.println("getRescueDays");
        RescueCase instance = null;
        int expResult = 0;
        int result = instance.getRescueDays();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDailyCareCost method, of class RescueCase.
     */
    @Test
    public void testGetDailyCareCost() {
        System.out.println("getDailyCareCost");
        RescueCase instance = null;
        double expResult = 0.0;
        double result = instance.getDailyCareCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStatus method, of class RescueCase.
     */
    @Test
    public void testGetStatus() {
        System.out.println("getStatus");
        RescueCase instance = null;
        RescueStatus expResult = null;
        RescueStatus result = instance.getStatus();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setStatus method, of class RescueCase.
     */
    @Test
    public void testSetStatus() {
        System.out.println("setStatus");
        RescueStatus newStatus = null;
        RescueCase instance = null;
        instance.setStatus(newStatus);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class RescueCase.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class RescueCaseImpl extends RescueCase {

        public RescueCaseImpl() {
            super("", "", "", "", "", 0, 0.0);
        }

        public String getRescueType() {
            return "";
        }

        public double calculateAdditionalCost() {
            return 0.0;
        }

        public RescuePriority determinePriority() {
            return null;
        }

        public String getSpecificDetails() {
            return "";
        }
    }
    
}
