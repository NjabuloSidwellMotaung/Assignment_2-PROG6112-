/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.rescueapp;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Francina
 */
public class RescuableIT {
    
    public RescuableIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of startRescue method, of class Rescuable.
     */
    @Test
    public void testStartRescue() {
        System.out.println("startRescue");
        Rescuable instance = new RescuableImpl();
        instance.startRescue();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of completeRescue method, of class Rescuable.
     */
    @Test
    public void testCompleteRescue() {
        System.out.println("completeRescue");
        Rescuable instance = new RescuableImpl();
        instance.completeRescue();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateSummary method, of class Rescuable.
     */
    @Test
    public void testGenerateSummary() {
        System.out.println("generateSummary");
        Rescuable instance = new RescuableImpl();
        String expResult = "";
        String result = instance.generateSummary();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class RescuableImpl implements Rescuable {

        public void startRescue() {
        }

        public void completeRescue() {
        }

        public String generateSummary() {
            return "";
        }
    }
    
}
