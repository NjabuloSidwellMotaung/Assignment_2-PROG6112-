/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.rescueapp;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Francina
 */
public class EndangeredSpeciesRescueIT {
    
    public EndangeredSpeciesRescueIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getRescueType method, of class EndangeredSpeciesRescue.
     */
    @Test
    public void testGetRescueType() {
        System.out.println("getRescueType");
        EndangeredSpeciesRescue instance = null;
        String expResult = "";
        String result = instance.getRescueType();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculateAdditionalCost method, of class EndangeredSpeciesRescue.
     */
    @Test
    public void testCalculateAdditionalCost() {
        System.out.println("calculateAdditionalCost");
        EndangeredSpeciesRescue instance = null;
        double expResult = 0.0;
        double result = instance.calculateAdditionalCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of determinePriority method, of class EndangeredSpeciesRescue.
     */
    @Test
    public void testDeterminePriority() {
        System.out.println("determinePriority");
        EndangeredSpeciesRescue instance = null;
        RescuePriority expResult = null;
        RescuePriority result = instance.determinePriority();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSpecificDetails method, of class EndangeredSpeciesRescue.
     */
    @Test
    public void testGetSpecificDetails() {
        System.out.println("getSpecificDetails");
        EndangeredSpeciesRescue instance = null;
        String expResult = "";
        String result = instance.getSpecificDetails();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getClassification method, of class EndangeredSpeciesRescue.
     */
    @Test
    public void testGetClassification() {
        System.out.println("getClassification");
        EndangeredSpeciesRescue instance = null;
        String expResult = "";
        String result = instance.getClassification();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSecurityCost method, of class EndangeredSpeciesRescue.
     */
    @Test
    public void testGetSecurityCost() {
        System.out.println("getSecurityCost");
        EndangeredSpeciesRescue instance = null;
        double expResult = 0.0;
        double result = instance.getSecurityCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isSpecialistTeamRequired method, of class EndangeredSpeciesRescue.
     */
    @Test
    public void testIsSpecialistTeamRequired() {
        System.out.println("isSpecialistTeamRequired");
        EndangeredSpeciesRescue instance = null;
        boolean expResult = false;
        boolean result = instance.isSpecialistTeamRequired();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
